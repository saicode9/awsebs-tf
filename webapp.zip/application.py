from flask import Flask
application = Flask(__name__)

@application.route("/")
def index():
    return "Welcome to Hello World WebApp - Using AWS-Beanstack!"
